//
//  CotizacionViewController.swift
//  Avance2_RAGG
//
//  Created by user190574 on 5/28/21.
//  Copyright © 2021 user190574. All rights reserved.
//

import UIKit


class CotizacionViewController: UIViewController {

    @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var phoneTextField: UITextField!
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var messageTextField: UITextField!
    @IBOutlet weak var enviarButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        
    }

    @IBAction func enviarButtonAction(_ sender: Any) {
        
        if let _ = nameTextField.text, let _ = phoneTextField.text, let _ = emailTextField.text, let _ = messageTextField.text {
            
        }
    }
}
