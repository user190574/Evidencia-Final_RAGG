//
//  ViewController.swift
//  Avance2_RAGG
//
//  Created by user190574 on 4/18/21.
//  Copyright © 2021 user190574. All rights reserved.
//

import UIKit

class SignInViewController: UIViewController {

    
   
    @IBOutlet weak var txtusername: UITextField!
    @IBOutlet weak var txtpassword: UITextField!
    @IBOutlet weak var btnentrar: UIButton!
    @IBOutlet weak var signUpButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        
    }
    
    @IBAction func signInButtonAction(_ sender: Any) {
        
        if let _ = txtusername.text, let _ = txtpassword.text {
            
        }
    }
    
    @IBAction func signUpButtonAction(_ sender: Any) {
        
         if let _ = txtusername.text, let _ = txtpassword.text {
                   
        }
    }
}

