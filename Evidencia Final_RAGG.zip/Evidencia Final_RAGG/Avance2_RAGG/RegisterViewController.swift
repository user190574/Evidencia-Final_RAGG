//
//  RegisterViewController.swift
//  Avance2_RAGG
//
//  Created by user190574 on 5/28/21.
//  Copyright © 2021 user190574. All rights reserved.
//

import UIKit

class RegisterViewController: UIViewController {
    
    
    @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var lastnameTextField: UITextField!
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var phoneTextField: UITextField!
    @IBOutlet weak var registerButton: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        
    }
    
    
    @IBAction func registerButtonAction(_ sender: Any) {
        
        if let _ = nameTextField.text, let _ = lastnameTextField.text, let _ = emailTextField.text, let _ = passwordTextField.text, let _ = phoneTextField.text {
            
        }
    }
}
